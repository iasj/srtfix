#!/usr/bin/env python
import re
import sys

if len(sys.argv) > 1:
  filename = sys.argv[1]

  file = open(filename,'r').read()

  lines = re.split('\n',file)

  paragraphs = []

  LEN = len(lines)

  def empty(string):
    string=string.strip()
    return not string

  i = 0
  while i < LEN:
    if not empty(lines[i]):
      paragraph = []
      while not empty(lines[i]) and i!=LEN:
        paragraph.append(lines[i])
        i+=1
      paragraphs.append(paragraph)
    i+=1

  lines = []

  for i in range(len(paragraphs)):
    index = i+1
    paragraph = paragraphs[i]
    lines.append(str(index))
    for line in paragraph:
      lines.append(line)
    lines.append('')

  output = open(filename,'w')
  output.write("\n".join(lines))
  output.close()
