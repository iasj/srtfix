#!/usr/bin/env python
import re
import sys
import os

if len(sys.argv) > 1:
  file = sys.argv[1].strip()
  dest = re.sub('\.txt$','.srt',file)
  os.rename(file,dest)
