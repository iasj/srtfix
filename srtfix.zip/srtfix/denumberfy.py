#!/usr/bin/env python
import re
import sys

if len(sys.argv) > 1:
  filename = sys.argv[1]
  file = open(filename,'r').read()

  lines = re.split('\n',file)

  i=0
  for line in lines:
    if re.search('^\d+$',line) is not None:
      lines[i] = ''
    i+=1

  output = open(filename,'w')
  output.write("\n".join(lines))
  output.close()
